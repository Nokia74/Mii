1) authui.dll, imageres.dll and LogonUI.exe goes to system32 folder.
2) authui.dll.mui goes to system32/en-us folder.
3) Enjoy your vista startup orb in Windows 7!